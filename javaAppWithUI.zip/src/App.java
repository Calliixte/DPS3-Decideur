import javax.swing.SwingUtilities;

import config.Myfonts;
import vues.AppWindow;

public class App {
    public static void main(String[] args) throws Exception {
        // permet d'utiliser les fonts ajoutées dans le fichier
        Myfonts.initialize();
        
        // parce que JFrame n'est pas thread safe, 
        // il faut utiliser le tricks suivant pour tout run dans le même thread
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {

                AppWindow fenetre = new AppWindow();
                // fenetre.afficherConnexion();
                fenetre.afficherAccueil();
                fenetre.show();
            }
        });
    }
    
}
