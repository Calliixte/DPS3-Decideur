package modele;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;

// la classe du décideur (l'utilisateur courant de l'app)
// 
public class Decideur {
    public static final String DFT_PFP_PATH = "media/profilepic.png";
    private static int idUtilisateur;
    private static String pseudo;
    private static String nom;
    private static String prenom;
    private static URL lienPhotoProfil; 

    private static ArrayList<Groupe> groupesDeDecision;

    // la classe Decideur n'est pas instantiable
    private Decideur() {}
    
    public static void initialiser() {
        // TODO : empêcher la connexion de l'utilisateur à l'app s'il n'est décideur d'aucun des groupes don til est membre 
        // TODO : fetch les données JSON dans les attributs de Decideur
        String lienPhotoProfil; // lien récuéré via l'API REST
        try {
            Decideur.lienPhotoProfil = new URI(lienPhotoProfil).toURL();
        }
        catch (MalformedURLException | URISyntaxException e) {
            Decideur.lienPhotoProfil = null;
        }

        // TODO : créer un objet Groupe pour chaque groupe dont le Decideur est décisionnaire et l'ajouter à groupeDeDecision
    }

    public static URL getLienPhotoProfil() {
        return lienPhotoProfil;
    }
    
    public static ArrayList<Groupe> getGroupesDeDecision() {
        return groupesDeDecision;
    }
}
