package vues;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

import vues.connexion.JPanelConnexion;
import vues.sideBar.JPanelSideBar;

public class AppWindow {
    JFrame frame;
    public AppWindow() {
        frame = new JFrame("DPS3 Décideur");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension fsize = new Dimension((int)screen.getWidth()/2, (int)screen.getHeight()/2);

        frame.setSize(fsize);
        frame.setMinimumSize(fsize);
        frame.setPreferredSize(fsize);
        frame.setMaximumSize(screen);

        frame.setLocationRelativeTo(null); 
    }

    private void reset() {
        // nota : le contentpane est un panel qui est par défaut dans un jframe
        frame.getContentPane().removeAll();

        // si des problèmes dans le futur, décommenter les lignes suivantes :
        // frame.getContentPane().revalidate();
        // frame.getContentPane().repaint();
    }

    public void show() {
        frame.setVisible(true);
    }

    public void afficherConnexion() {
        reset();
        frame.add(new JPanelConnexion(), BorderLayout.CENTER);
    }

    public void afficherAccueil() {
        reset();
        frame.add(new JPanelSideBar(), BorderLayout.WEST);
        frame.add(new JPanelConnexion(), BorderLayout.CENTER);
    }
}
