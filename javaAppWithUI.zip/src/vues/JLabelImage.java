package vues;

import java.awt.Dimension;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class JLabelImage extends JLabel{
    private ImageIcon img; // the orginial image

    public JLabelImage() {
        super();
        img = null;
    }

    public JLabelImage(String filename) {
        img = new ImageIcon(filename);
        setIcon(img);
    }

    public void setIcon(String filename) {
        img = new ImageIcon(filename);
        setIcon(img);
    }

    public void setImageSize(Dimension dimension) {
        setImageSize((int)dimension.getWidth(), (int)dimension.getHeight());
    }

    public void setImageSize(int width, int height) {
        setIcon(scaleSmooth(width, height));
    }

    private ImageIcon scaleSmooth(int width, int height) {
        return new ImageIcon(img.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH));
    }

    private ImageIcon scaleFast(int width, int height) {
        return new ImageIcon(img.getImage().getScaledInstance(width, height, Image.SCALE_FAST));
    }
}
