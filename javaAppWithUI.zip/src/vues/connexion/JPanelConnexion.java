package vues.connexion;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JPanel;

import utils.Layouts.GBL;

public class JPanelConnexion extends JPanel{

    public JPanelConnexion() 
    {
        super();

        
        JPanelFormConnexion panel = new JPanelFormConnexion();
        
        // Box box = new Box(BoxLayout.Y_AXIS);
        // box.add(Box.createVerticalGlue());
        // box.add(panel);
        // box.add(Box.createVerticalGlue());

        // add(box);

        setLayout(new GridBagLayout());
        GridBagConstraints c = GBL.getConstraint(0, 0);
        c.anchor = GridBagConstraints.CENTER;
        c.ipadx = 30;
        c.ipady = 30;
        add(panel, c);
    }
}