package vues.connexion;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import utils.Layouts.GBL;
import vues.JPanelRound;

public class JPanelFormConnexion extends JPanelRound {
    private JButton jb_valider = new JButton("Se connecter");
    private JTextField jtf_userId = new JTextField(15);
    private JPasswordField jpf_userPsw = new JPasswordField(15);

    private JLabel jl_titre = new JLabel("Connexion");
    private JLabel jl_userId = new JLabel("Email ou Nom d'utilisateur");
    private JLabel jl_userPsw = new JLabel("Mot de passe");

    public JPanelFormConnexion() {
        super();
        GridBagConstraints c;

        setLayout(new GridBagLayout());
        setRound(40, 40, 40, 40);
        

        // setSize(500, 500);

        // setBorder(new LineBorder(Color.ORANGE, 5, true));
        setBackground(Color.GRAY);

        // Dimension expectedDimension = new Dimension(100, 100);
        
        // setPreferredSize(expectedDimension);
        setMaximumSize(new Dimension(400, 500));
        // setMinimumSize(expectedDimension);



        jl_titre.setFont(new Font("Josefin Sans Bold", Font.PLAIN, 40));

        jl_userId.setFont(new Font("Istok Web Bold", Font.PLAIN, 15));

        jl_userPsw.setFont(new Font("Istok Web Bold", Font.PLAIN, 15));
        
        jb_valider.setFont(new Font("Istok Web Bold", Font.PLAIN, 20));
        jb_valider.setFocusPainted(false);
        jb_valider.setBorderPainted(false);
        jb_valider.setBackground(Color.LIGHT_GRAY);
        jb_valider.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // ---------------------
        // tout ajouter au panel
        // ---------------------
        c = GBL.getConstraint(0, 0, 2, 1);
        c.insets = new Insets(0, 0, 10, 0);
        c.anchor = GridBagConstraints.LINE_START;
        add(jl_titre, c);

        c = GBL.getConstraint(0, 1);
        c.insets = new Insets(5, 5, 5, 5);
        c.anchor = GridBagConstraints.LINE_START;
        add(jl_userId, c);

        c = GBL.getConstraint(1, 1);
        c.insets = new Insets(5, 5, 5, 5);
        c.fill = GridBagConstraints.HORIZONTAL;
        add(jtf_userId, c);

        c = GBL.getConstraint(0, 2);
        c.insets = new Insets(5, 5, 5, 5);
        c.anchor = GridBagConstraints.LINE_START;
        add(jl_userPsw, c);

        c = GBL.getConstraint(1, 2);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(5, 5, 5, 5);
        add(jpf_userPsw, c);
        
        c = GBL.getConstraint(0, 3, 2, 1);
        c.insets = new Insets(10, 0, 0, 0);
        add(jb_valider, c);
    }
}