package vues.sideBar;

import java.awt.Color;
import java.awt.Dimension;

import vues.JLabelImage;
import vues.JPanelRound;

public class JPanelQuickNavBar extends JPanelRound {
    JLabelImage jli_logo = new JLabelImage("media\\logo.png");
    JLabelImage jli_profil = new JLabelImage("media\\profilepic.png");

    public JPanelQuickNavBar() {
        super();

        setRound(40, 40, 40, 40);
        setBackground(Color.LIGHT_GRAY);
        
        Dimension imgSize = new Dimension(100, 100);
        jli_logo.setImageSize(imgSize);
        jli_profil.setImageSize(imgSize);

        add(jli_logo);
        add(jli_profil);
    }

}
