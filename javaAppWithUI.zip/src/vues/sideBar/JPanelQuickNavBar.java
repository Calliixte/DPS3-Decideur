package vues.sideBar;

import java.awt.Color;
import java.awt.Dimension;
import java.net.URI;
import java.net.URL;

import javax.swing.ImageIcon;

import modele.Decideur;
import vues.reusables.JLabelImage;
import vues.reusables.JPanelRound;

public class JPanelQuickNavBar extends JPanelRound {
    JLabelImage jli_logo = new JLabelImage("media\\logo.png");
    JLabelImage jli_profil = new JLabelImage(Decideur.DFT_PFP_PATH);

    public JPanelQuickNavBar() {
        super();

        setRounds(40, 40, 40, 40);
        setBackground(Color.WHITE);

        Dimension imgSize = new Dimension(100, 100);
        
        try {
            URL url = new URI("file://media/profilepic.png").toURL();
            ImageIcon pfpReelle = new ImageIcon(url);
            // si pfpReelle a été créée avec succès, elle remplace la photo de profil par défaut
            jli_profil.setIcon(pfpReelle);
        }catch(Exception e) {}
        
        jli_logo.setImageSize(imgSize);
        jli_profil.setImageSize(imgSize);
        
        // TODO : faire un masque autour de la photo de profil pour qu'elle soit toujours ronde

        add(jli_logo);
        add(jli_profil);
    }

}
