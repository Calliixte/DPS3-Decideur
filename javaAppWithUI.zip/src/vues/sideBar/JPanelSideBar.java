package vues.sideBar;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JLabel;
import javax.swing.JPanel;

import utils.Layouts.GBL;

public class JPanelSideBar extends JPanel {
    JPanelQuickNavBar jp_quickNavBar = new JPanelQuickNavBar();
    JLabel jl_titre = new JLabel("Groupes de Décision");
    JScrollPaneLesGroupes jsp_lesGroupes = new JScrollPaneLesGroupes();

    public JPanelSideBar() {
        super();

        setLayout(new GridBagLayout());
        GridBagConstraints c;
        
        setBackground(Color.BLUE);

        jl_titre.setFont(new Font("Josefin Sans Bold", Font.PLAIN, 30));
        jl_titre.setForeground(Color.WHITE);
        
        // ajout de tous les composants
        c = GBL.getConstraint(0, 0);
        c.insets = new Insets(10, 10, 10, 10);
        add(jp_quickNavBar, c);

        c.gridy = 1;
        add(jl_titre, c);

        c.gridy = 2;
        c.fill = GridBagConstraints.BOTH;
        c.weighty = 1;
        add(jsp_lesGroupes, c);
        // JPanel test = new JPanel();
        // JScrollPane scrollFrame = new JScrollPane(test);
        // // scrollFrame.setOpaque(false);
        // // scrollFrame.getViewport().setOpaque(false);
        // // scrollFrame.setBorder(null);
        // // scrollFrame.setViewportBorder(null);
        // // test.setOpaque(false);
        // scrollFrame.setPreferredSize(jp_quickNavBar.getSize());
        // Dimension testSize = new Dimension(scrollFrame.getSize().width, 800);
        // test.setPreferredSize(testSize);
        // // test.setAutoscrolls(true);
        // // this.add(scrollFrame);
        // add(scrollFrame, c);

        // le dernier Panel sert à remplir l'espace restant
        // cela permet de coller tous les composants en haut
        c.gridy = 3;
        c.weighty = 0.25;
        // décommenter les lignes suivantes pour le debug
        // c.setBackground(Color.RED);
        // c.fill = GridBagConstraints.BOTH;
        JPanel jp_filler = new JPanel();
        jp_filler.setOpaque(false);
        add(jp_filler, c);

    }

}
