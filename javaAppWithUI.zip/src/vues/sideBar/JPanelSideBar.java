package vues.sideBar;

import java.awt.Color;

import javax.swing.JPanel;

public class JPanelSideBar extends JPanel {
    public JPanelSideBar() {
        super();

        // setLayout(new GridBagLayout());
        setBackground(Color.BLUE);
        add(new JPanelQuickNavBar());

    }

}
