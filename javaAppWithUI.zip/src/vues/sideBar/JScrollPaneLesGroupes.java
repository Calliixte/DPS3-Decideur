package vues.sideBar;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import modele.Groupe;
import utils.Layouts.GBL;

public class JScrollPaneLesGroupes extends JScrollPane{
    JPanel jp_lesGroupes = new JPanel(new GridBagLayout());

    public JScrollPaneLesGroupes() {
        super();
        // FlowLayout layout = new FlowLayout();
        // layout.setAlignment(FlowLayout.LEFT);
        // JPanel jp_lesGroupes = new JPanel(layout);
        
        setViewportView(jp_lesGroupes);
        jp_lesGroupes.setBackground(Color.RED);

        // ajout de tous les composants
        GridBagConstraints c;
        c = GBL.getConstraint(0, 0);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(5, 0, 5, 0);
        c.ipadx = 150;
        System.out.println(getPreferredSize().width);
        
        // Pour débugger, **commentez** la ligne suivante
        // --------------------------------------------
        // ArrayList<Groupe> groupes = Decideur.getGroupesDeDecision();
        
        // Pour débugger, décommentez les lignes suivantes
        // --------------------------------------------
        ArrayList<Groupe> groupes = new ArrayList<Groupe>(){{
            add(new Groupe("groupe x"));
            add(new Groupe("groupe y"));
            add(new Groupe("groupe z"));
            add(new Groupe("groupe z"));
            add(new Groupe("groupe z"));
            add(new Groupe("groupe z"));
            add(new Groupe("groupe z"));
            add(new Groupe("groupe z"));
        }};
        
        for (int i=0; i<groupes.size(); i++) {
            c.gridy = i;
            String nomGroupe = groupes.get(i).getNomGroupe();
            JPanelPetitGroupe jp_groupe = new JPanelPetitGroupe(nomGroupe);
            jp_lesGroupes.add(jp_groupe, c);
        }
        c.insets = new Insets(0, 0, 0, 0);
        c.gridy++; 
        c.weighty = 1;
        c.fill = GridBagConstraints.BOTH;
        JPanel jp_filler = new JPanel();
        jp_filler.setOpaque(false);
        jp_lesGroupes.add(jp_filler, c);

        setBorder(null);

        setOpaque(false);
        getViewport().setOpaque(false);
        jp_lesGroupes.setOpaque(false);
    }
}
